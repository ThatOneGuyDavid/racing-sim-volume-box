# Vertical cradle interface

The cradle installs straight down along Z. In the viewer, use **Lift cradle** to expose the retainers and magnet pockets. At 17 mm of lift the cradle underside clears both retainer heads. The approved outer seam is the seating reference. The box has a continuous 3 mm shelf and a 3.5 mm upright wall behind both retainers. Install the retainer screws from inside through the bottom access.

## Hardware and assembly

- Install eight M3 heat-set inserts from the open underside before fitting the PCB or cover. The four PCB seats and four cover mounts have Ø4.4 mm blind bores, 7 mm deep, with 2 mm of backing. Check the pilot diameter and depth specified for your inserts, and seat them flush. The cover mounts and rear PCB mounts have 2 mm of plastic around each bore. Both front PCB mounts follow the original flying-support nose and slope, leaving 1.3 mm directly ahead of the bore. All eight enclosure insert bosses have flat sides with 1.2 mm corner radii. Each rear PCB boss joins its neighboring cover boss with a short 6 mm wide bridge. Both bridges start 0.5 mm above the PCB. The space between the left and right pairs stays open for board components. The rear-left cover screw and boss share an axis at X=26.32, Y=103.5 mm. Its rear web starts at X=23.72 mm, leaving 0.40 mm to the edge of the 15.5 mm RCA passage. The closest modeled gap to the audio assembly during vertical installation is 0.30 mm. Print the matching cover and shell together.
- Print **two** copies of `M3-retainer-print-2.stl`. The file is oriented with the wide head on the print bed and the insert opening facing up.
- Each retainer accepts one M3 heat-set insert in its flat mounting face. The bore is Ø4.4 mm and 7.0 mm deep. Fit the insert flush. Secure each retainer with an M3 screw from inside the enclosure through its 3.5 mm mounting web. An M3 × 8 mm screw nominally engages 4.5 mm past the web; check the usable thread length of the insert you use.
- Glue four Ø12 × 3 mm magnets into the Ø12.30 mm blind pockets. Dry-fit and mark polarity first. Use the same upward-facing pole at both shelf stations and the attracting pole facing down on each cradle. The magnet faces are 0.20 mm apart when the cradle rests on the flat shelf and 0.45 mm apart at the saved assembly position.
- Lower the cradle over the two retainer heads. The slots guide the cradle, the flat shelf supports the cradle and the magnets resist lift. Test sliding fit, lift force and rocking with the actual prints and hardware.

## Datums for another cradle

All values are millimetres in the saved assembly coordinate system. Positive Y points toward the cable exit. The flat shelf is at Z = 47.00. The saved cradle underside is at Z = 47.25 and can settle 0.25 mm onto the shelf. The vertical box face is at Y = 55.00; the mating cradle face starts at Y = 55.25.

| Feature | Locations and dimensions |
|---|---|
| Fixed retainer axes | X = 31.79 and 91.79, Z = 57.00. Start at Y = 55.00 and point toward positive Y. |
| Retainer shape | Ø9.0 × 8.4 neck followed by a Ø12.8 × 3.1 head. |
| Cradle slots | Open downward. Neck slot R4.85, head slot R6.80. The wider head slot begins at Y = 63.05. |
| Magnet stations | X = 23.79 and 99.79, Y = 94.00, 76.00 mm center spacing. |
| Magnet pockets | Shelf pocket floor Z = 43.90 with 1.50 mm of backing. Shelf magnet face Z = 46.90, 0.10 mm below the shelf. Cradle pocket roof Z = 50.35. Its magnet face is 0.10 mm inside the cradle underside. |

In FreeCAD, **Interchange datum · subtract from replacement cradle** contains the two open-bottom retainer slots and upper magnet pockets as one subtractive tool. Position the replacement cradle at the datums above, preserve material over the pockets, and subtract a copy of the tool. The shelf, retainer and magnet objects give the matching stationary geometry.

The saved design passed a continuous vertical-clearance check and collision tests at 17 discrete lifts from 0 to 48 mm. Physical tolerances and magnetic holding force still require a hardware fit check.
